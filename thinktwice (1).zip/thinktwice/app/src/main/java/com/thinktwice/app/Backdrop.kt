package com.thinktwice.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.view.Display
import androidx.annotation.RequiresApi

/**
 * Fondo de la pantalla de pausa: la app que intentabas abrir, MUY reducida (≈36 px de ancho) y por tanto desenfocada.
 * La captura completa se descarta al instante; solo vive en memoria (nunca se guarda ni se envía) hasta cerrar la pausa.
 * Necesita Android 11+ y canTakeScreenshot en el servicio. Si falla o está desactivado, se usa el fondo oscuro normal.
 */
object Backdrop {
    private const val PREFS = "tt_prefs"
    private const val KEY = "backdrop"
    @Volatile private var bitmap: Bitmap? = null
    @Volatile private var forPkg: String? = null

    fun enabled(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, true)
    fun setEnabled(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply()
        if (!on) clear()
    }

    fun take(pkg: String): Bitmap? = if (forPkg == pkg) bitmap else null
    fun clear() { bitmap = null; forPkg = null }

    /** Reduce por mitades hasta ~36 px de ancho: promedia píxeles y elimina cualquier contenido legible. */
    private fun tiny(src: Bitmap): Bitmap {
        var cur = src
        while (cur.width / 2 >= 36) {
            val next = Bitmap.createScaledBitmap(cur, cur.width / 2, (cur.height / 2).coerceAtLeast(1), true)
            if (cur !== src) cur.recycle()
            cur = next
        }
        return cur
    }

    @RequiresApi(Build.VERSION_CODES.R)
    fun capture(service: AccessibilityService, pkg: String, done: () -> Unit) {
        try {
            service.takeScreenshot(Display.DEFAULT_DISPLAY, service.mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                            if (hw != null) {
                                val soft = hw.copy(Bitmap.Config.ARGB_8888, false)
                                hw.recycle()
                                if (soft != null) {
                                    val small = tiny(soft)
                                    if (small !== soft) soft.recycle()
                                    bitmap = small; forPkg = pkg
                                }
                            }
                        } catch (_: Throwable) {
                        } finally {
                            runCatching { result.hardwareBuffer.close() }
                        }
                        done()
                    }
                    override fun onFailure(errorCode: Int) { done() }
                })
        } catch (_: Throwable) { done() }
    }
}
